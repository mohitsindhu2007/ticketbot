# Phantom Cheats Discord Ticket Bot

A professional Discord ticket management bot with custom panels for gaming-related customer support.

## Features

- **Custom Ticket Panels**: Create sleek, professional panels with custom images and templates
- **Role-Based Link Filter**: Control which roles can send links in your server
- **Auto-Response System**: Automatically respond to tickets based on their type
- **Ticket Management**: Add/remove users, close/reopen tickets, and more
- **Logging System**: Keep track of all ticket activities
- **Persistent Hosting**: Designed to run reliably on WispByte hosting

## Installation

### Required Packages

The bot requires the following packages:
```
discord.py>=2.3.0
flask>=2.3.0
gunicorn>=23.0.0
python-dotenv>=1.0.0
email_validator>=2.0.0
flask-sqlalchemy>=3.0.0
psycopg2-binary>=2.9.6
```

### Environment Variables

Set the following environment variables:
- `BOT_TOKEN`: Your Discord Bot Token

## Setup

1. Clone this repository
2. Install required packages
3. Set up environment variables 
4. Run the bot using `python main.py` or for WispByte hosting: `gunicorn --bind 0.0.0.0:5000 --reuse-port --reload main:app`

## Running the Bot

### Direct Execution
```
python main.py
```

### WispByte Hosting
```
gunicorn --bind 0.0.0.0:5000 --reuse-port --reload main:app
```

## Commands

### Setup Commands
- `/setup` - Configure the ticket system
- `/settings` - View current settings

### Ticket Panel Commands
- `/createpanel` - Create a ticket panel
- `/editpanel` - Edit an existing panel
- `/deletepanel` - Delete a ticket panel

### Ticket Management
- `/close` - Close a ticket
- `/reopen` - Reopen a closed ticket
- `/add` - Add a user to a ticket
- `/remove` - Remove a user from a ticket

### Link Filter
- `/linkfilter` - Enable or disable link filter for a role
- `/listlinkroles` - List roles that can send links

## Template Types

- **Gaming**: Red theme for gaming support
- **Billing**: Green theme for billing support
- **General**: Gray theme for general inquiries

## Customization

You can customize various aspects of the bot by modifying the `config.json` file.

## Support

Need help? Join our Discord server or open an issue on GitHub.